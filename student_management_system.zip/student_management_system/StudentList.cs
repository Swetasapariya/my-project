﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace student_management_system
{
    public partial class Studentlist : Form
    {
        public Studentlist()
        {
            InitializeComponent();
        }
       
        private void Studentlist_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'student_management_systemDBDataSet2.Student' table. You can move, or remove it, as needed.
            //this.studentTableAdapter.Fill(this.student_management_systemDBDataSet2.Student);
            Getdata();

        }
        public void Getdata()
        {

            string sql = "SELECT * from Student";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void Backhbtn_Click(object sender, EventArgs e)
        {
            Student_Home hs = new Student_Home();
            hs.Show();
            this.Hide();
          
        }

      
         private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
         {

            if (e.RowIndex >= 0) // Ensures the row clicked is valid
            {
                SearchStudents searchStudents = new SearchStudents();

                searchStudents.Idstxt.Text = this.dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                searchStudents.Studnmetxt.Text = this.dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();

                if (dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString() == "Female")
                {
                    searchStudents.Femrbtn.Checked = true;
                }
                else
                {
                    searchStudents.Gndrbtn.Checked = true;
                }

                searchStudents.DateTimePicker1.Text = this.dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                searchStudents.Cntnmtxt.Text = this.dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                searchStudents.Pintxt.Text = this.dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                searchStudents.Citycombo.Text = this.dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                searchStudents.Adrestxt.Text = this.dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();

                searchStudents.Show();
            }

        }

       
    }
}
