﻿namespace student_management_system
{
    partial class searchstudentValue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.student_management_systemDBDataSet2 = new student_management_system.student_management_systemDBDataSet2();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.studentTableAdapter = new student_management_system.student_management_systemDBDataSet2TableAdapters.StudentTableAdapter();
            this.studentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label14 = new System.Windows.Forms.Label();
            this.Idstxt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Studnmetxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Cntnmtxt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Gndrbtn = new System.Windows.Forms.RadioButton();
            this.Femrbtn = new System.Windows.Forms.RadioButton();
            this.Citycombo = new System.Windows.Forms.ComboBox();
            this.Addsbtn = new System.Windows.Forms.Button();
            this.DateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Adrestxt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Pintxt = new System.Windows.Forms.TextBox();
            this.Updatesbtn = new System.Windows.Forms.Button();
            this.Deletesbtn = new System.Windows.Forms.Button();
            this.Resrtbtn = new System.Windows.Forms.Button();
            this.Searchtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Searchbtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.studentIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateofBirthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pinCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btnbkh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_management_systemDBDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "Student";
            this.studentBindingSource.DataSource = this.student_management_systemDBDataSet2;
            // 
            // student_management_systemDBDataSet2
            // 
            this.student_management_systemDBDataSet2.DataSetName = "student_management_systemDBDataSet2";
            this.student_management_systemDBDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(441, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(317, 30);
            this.label1.TabIndex = 50;
            this.label1.Text = "Students Details";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // studentsBindingSource
            // 
            this.studentsBindingSource.DataMember = "Students";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(45, 547);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 20);
            this.label14.TabIndex = 48;
            this.label14.Text = "Address";
            // 
            // Idstxt
            // 
            this.Idstxt.Location = new System.Drawing.Point(180, 92);
            this.Idstxt.Name = "Idstxt";
            this.Idstxt.Size = new System.Drawing.Size(218, 22);
            this.Idstxt.TabIndex = 51;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 210);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 20);
            this.label9.TabIndex = 45;
            this.label9.Text = "Contact Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 20);
            this.label4.TabIndex = 42;
            this.label4.Text = "Student Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(56, 341);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 20);
            this.label12.TabIndex = 47;
            this.label12.Text = "City";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(45, 262);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 20);
            this.label7.TabIndex = 43;
            this.label7.Text = "Gender";
            // 
            // Studnmetxt
            // 
            this.Studnmetxt.Location = new System.Drawing.Point(180, 141);
            this.Studnmetxt.Name = "Studnmetxt";
            this.Studnmetxt.Size = new System.Drawing.Size(320, 22);
            this.Studnmetxt.TabIndex = 52;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 41;
            this.label3.Text = " Student Id";
            // 
            // Cntnmtxt
            // 
            this.Cntnmtxt.Location = new System.Drawing.Point(195, 208);
            this.Cntnmtxt.MaxLength = 10;
            this.Cntnmtxt.Name = "Cntnmtxt";
            this.Cntnmtxt.Size = new System.Drawing.Size(298, 22);
            this.Cntnmtxt.TabIndex = 53;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(18, 401);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 20);
            this.label8.TabIndex = 44;
            this.label8.Text = "Date Of Birth";
            // 
            // Gndrbtn
            // 
            this.Gndrbtn.AutoSize = true;
            this.Gndrbtn.Checked = true;
            this.Gndrbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Gndrbtn.Location = new System.Drawing.Point(195, 274);
            this.Gndrbtn.Name = "Gndrbtn";
            this.Gndrbtn.Size = new System.Drawing.Size(61, 20);
            this.Gndrbtn.TabIndex = 56;
            this.Gndrbtn.TabStop = true;
            this.Gndrbtn.Text = "Male";
            this.Gndrbtn.UseVisualStyleBackColor = true;
            // 
            // Femrbtn
            // 
            this.Femrbtn.AutoSize = true;
            this.Femrbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Femrbtn.Location = new System.Drawing.Point(319, 274);
            this.Femrbtn.Name = "Femrbtn";
            this.Femrbtn.Size = new System.Drawing.Size(79, 20);
            this.Femrbtn.TabIndex = 57;
            this.Femrbtn.Text = "Female";
            this.Femrbtn.UseVisualStyleBackColor = true;
            // 
            // Citycombo
            // 
            this.Citycombo.FormattingEnabled = true;
            this.Citycombo.Items.AddRange(new object[] {
            "Rajkot",
            "Ahmadabad",
            "Baroda",
            "Surat",
            "Junagadh",
            "Jamnager",
            "Anand",
            "Kach",
            "Veraval",
            "Surendranager"});
            this.Citycombo.Location = new System.Drawing.Point(195, 337);
            this.Citycombo.Name = "Citycombo";
            this.Citycombo.Size = new System.Drawing.Size(230, 24);
            this.Citycombo.TabIndex = 59;
            // 
            // Addsbtn
            // 
            this.Addsbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Addsbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addsbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addsbtn.ForeColor = System.Drawing.Color.SkyBlue;
            this.Addsbtn.Location = new System.Drawing.Point(14, 656);
            this.Addsbtn.Name = "Addsbtn";
            this.Addsbtn.Size = new System.Drawing.Size(101, 40);
            this.Addsbtn.TabIndex = 49;
            this.Addsbtn.Text = "Add";
            this.Addsbtn.UseVisualStyleBackColor = false;
            this.Addsbtn.Click += new System.EventHandler(this.Addsbtn_Click);
            // 
            // DateTimePicker1
            // 
            this.DateTimePicker1.Location = new System.Drawing.Point(195, 401);
            this.DateTimePicker1.MaxDate = new System.DateTime(2024, 10, 2, 0, 0, 0, 0);
            this.DateTimePicker1.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.DateTimePicker1.Name = "DateTimePicker1";
            this.DateTimePicker1.Size = new System.Drawing.Size(253, 22);
            this.DateTimePicker1.TabIndex = 58;
            this.DateTimePicker1.Value = new System.DateTime(2024, 10, 2, 0, 0, 0, 0);
            // 
            // Adrestxt
            // 
            this.Adrestxt.Location = new System.Drawing.Point(180, 525);
            this.Adrestxt.Multiline = true;
            this.Adrestxt.Name = "Adrestxt";
            this.Adrestxt.Size = new System.Drawing.Size(329, 92);
            this.Adrestxt.TabIndex = 55;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(30, 477);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 20);
            this.label10.TabIndex = 46;
            this.label10.Text = "Pin Code";
            // 
            // Pintxt
            // 
            this.Pintxt.Location = new System.Drawing.Point(195, 475);
            this.Pintxt.MaxLength = 6;
            this.Pintxt.Name = "Pintxt";
            this.Pintxt.Size = new System.Drawing.Size(265, 22);
            this.Pintxt.TabIndex = 54;
            // 
            // Updatesbtn
            // 
            this.Updatesbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Updatesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Updatesbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatesbtn.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.Updatesbtn.Location = new System.Drawing.Point(141, 656);
            this.Updatesbtn.Name = "Updatesbtn";
            this.Updatesbtn.Size = new System.Drawing.Size(115, 40);
            this.Updatesbtn.TabIndex = 60;
            this.Updatesbtn.Text = "Edit";
            this.Updatesbtn.UseVisualStyleBackColor = false;
            this.Updatesbtn.Click += new System.EventHandler(this.Updatesbtn_Click);
            // 
            // Deletesbtn
            // 
            this.Deletesbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Deletesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Deletesbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletesbtn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Deletesbtn.Location = new System.Drawing.Point(282, 656);
            this.Deletesbtn.Name = "Deletesbtn";
            this.Deletesbtn.Size = new System.Drawing.Size(116, 40);
            this.Deletesbtn.TabIndex = 61;
            this.Deletesbtn.Text = "Remove";
            this.Deletesbtn.UseVisualStyleBackColor = false;
            this.Deletesbtn.Click += new System.EventHandler(this.Deletesbtn_Click);
            // 
            // Resrtbtn
            // 
            this.Resrtbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Resrtbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Resrtbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resrtbtn.ForeColor = System.Drawing.Color.Navy;
            this.Resrtbtn.Location = new System.Drawing.Point(429, 656);
            this.Resrtbtn.Name = "Resrtbtn";
            this.Resrtbtn.Size = new System.Drawing.Size(115, 40);
            this.Resrtbtn.TabIndex = 62;
            this.Resrtbtn.Text = "Reset";
            this.Resrtbtn.UseVisualStyleBackColor = false;
            this.Resrtbtn.Click += new System.EventHandler(this.Resrtbtn_Click);
            // 
            // Searchtxt
            // 
            this.Searchtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchtxt.Location = new System.Drawing.Point(180, 21);
            this.Searchtxt.Name = "Searchtxt";
            this.Searchtxt.Size = new System.Drawing.Size(218, 24);
            this.Searchtxt.TabIndex = 67;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 66;
            this.label2.Text = "Search Id";
            // 
            // Searchbtn
            // 
            this.Searchbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Searchbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Searchbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchbtn.ForeColor = System.Drawing.Color.Pink;
            this.Searchbtn.Location = new System.Drawing.Point(485, 21);
            this.Searchbtn.Name = "Searchbtn";
            this.Searchbtn.Size = new System.Drawing.Size(148, 40);
            this.Searchbtn.TabIndex = 68;
            this.Searchbtn.Text = "Search";
            this.Searchbtn.UseVisualStyleBackColor = false;
            this.Searchbtn.Click += new System.EventHandler(this.Searchbtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentIdDataGridViewTextBoxColumn,
            this.studentNameDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.dateofBirthDataGridViewTextBoxColumn,
            this.contactNumberDataGridViewTextBoxColumn,
            this.pinCodeDataGridViewTextBoxColumn,
            this.cityDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.studentBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(515, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(908, 470);
            this.dataGridView1.TabIndex = 69;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // studentIdDataGridViewTextBoxColumn
            // 
            this.studentIdDataGridViewTextBoxColumn.DataPropertyName = "Student_Id";
            this.studentIdDataGridViewTextBoxColumn.HeaderText = "Student_Id";
            this.studentIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.studentIdDataGridViewTextBoxColumn.Name = "studentIdDataGridViewTextBoxColumn";
            // 
            // studentNameDataGridViewTextBoxColumn
            // 
            this.studentNameDataGridViewTextBoxColumn.DataPropertyName = "Student_Name";
            this.studentNameDataGridViewTextBoxColumn.HeaderText = "Student_Name";
            this.studentNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.studentNameDataGridViewTextBoxColumn.Name = "studentNameDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // dateofBirthDataGridViewTextBoxColumn
            // 
            this.dateofBirthDataGridViewTextBoxColumn.DataPropertyName = "Date_of_Birth";
            this.dateofBirthDataGridViewTextBoxColumn.HeaderText = "Date_of_Birth";
            this.dateofBirthDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dateofBirthDataGridViewTextBoxColumn.Name = "dateofBirthDataGridViewTextBoxColumn";
            // 
            // contactNumberDataGridViewTextBoxColumn
            // 
            this.contactNumberDataGridViewTextBoxColumn.DataPropertyName = "Contact_Number";
            this.contactNumberDataGridViewTextBoxColumn.HeaderText = "Contact_Number";
            this.contactNumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.contactNumberDataGridViewTextBoxColumn.Name = "contactNumberDataGridViewTextBoxColumn";
            // 
            // pinCodeDataGridViewTextBoxColumn
            // 
            this.pinCodeDataGridViewTextBoxColumn.DataPropertyName = "Pin_Code";
            this.pinCodeDataGridViewTextBoxColumn.HeaderText = "Pin_Code";
            this.pinCodeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.pinCodeDataGridViewTextBoxColumn.Name = "pinCodeDataGridViewTextBoxColumn";
            // 
            // cityDataGridViewTextBoxColumn
            // 
            this.cityDataGridViewTextBoxColumn.DataPropertyName = "City";
            this.cityDataGridViewTextBoxColumn.HeaderText = "City";
            this.cityDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cityDataGridViewTextBoxColumn.Name = "cityDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.Searchbtn);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Searchtxt);
            this.groupBox1.Controls.Add(this.Resrtbtn);
            this.groupBox1.Controls.Add(this.Deletesbtn);
            this.groupBox1.Controls.Add(this.Updatesbtn);
            this.groupBox1.Controls.Add(this.Pintxt);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.Adrestxt);
            this.groupBox1.Controls.Add(this.DateTimePicker1);
            this.groupBox1.Controls.Add(this.Addsbtn);
            this.groupBox1.Controls.Add(this.Citycombo);
            this.groupBox1.Controls.Add(this.Femrbtn);
            this.groupBox1.Controls.Add(this.Gndrbtn);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.Cntnmtxt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Studnmetxt);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.Idstxt);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Location = new System.Drawing.Point(12, 51);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1429, 714);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // Btnbkh
            // 
            this.Btnbkh.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btnbkh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btnbkh.ForeColor = System.Drawing.Color.Red;
            this.Btnbkh.Location = new System.Drawing.Point(1273, 8);
            this.Btnbkh.Name = "Btnbkh";
            this.Btnbkh.Size = new System.Drawing.Size(152, 40);
            this.Btnbkh.TabIndex = 51;
            this.Btnbkh.Text = "Back";
            this.Btnbkh.UseVisualStyleBackColor = false;
            this.Btnbkh.Click += new System.EventHandler(this.Btnbkh_Click);
            // 
            // searchstudentValue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1437, 782);
            this.Controls.Add(this.Btnbkh);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "searchstudentValue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "searchstudentValue";
            this.Load += new System.EventHandler(this.searchstudentValue_Load);
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_management_systemDBDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.BindingSource studentsBindingSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private student_management_systemDBDataSet2 student_management_systemDBDataSet2;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private student_management_systemDBDataSet2TableAdapters.StudentTableAdapter studentTableAdapter;
        private System.Windows.Forms.Button Btnbkh;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateofBirthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pinCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Searchbtn;
        private System.Windows.Forms.Label label2;
        internal System.Windows.Forms.TextBox Searchtxt;
        private System.Windows.Forms.Button Resrtbtn;
        private System.Windows.Forms.Button Deletesbtn;
        private System.Windows.Forms.Button Updatesbtn;
        private System.Windows.Forms.TextBox Pintxt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Adrestxt;
        private System.Windows.Forms.DateTimePicker DateTimePicker1;
        private System.Windows.Forms.Button Addsbtn;
        private System.Windows.Forms.ComboBox Citycombo;
        private System.Windows.Forms.RadioButton Femrbtn;
        private System.Windows.Forms.RadioButton Gndrbtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Cntnmtxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Studnmetxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Idstxt;
        private System.Windows.Forms.Label label14;
    }
}