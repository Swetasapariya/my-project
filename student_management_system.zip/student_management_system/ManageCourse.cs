﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management_system
{
    public partial class ManageCourse : Form
    {
        public ManageCourse()
        {
            InitializeComponent();
            this.CourseList.SelectedIndexChanged += new System.EventHandler(this.CourseList_SelectedIndexChanged);
        }
        int aa;
        private void Updatedetailsbtn_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE Courses SET  CousreName = '" + Coursenameprtxt.Text + "', Timeduration = '" + Numbertxt.Text + "', Fees = '" + Coursefeetxt.Text + "' WHERE CourseId = '" + Courseidtxt.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GetData();
            MessageBox.Show("Course Record Updated!", "Update Student", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
        private void LoadCourseList()
        {
            string sql = "SELECT * FROM Courses";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GetData();
            CourseList.Items.Clear(); // Clear the list before loading
            foreach (DataRow row in dt.Rows)
            {
                // Add course names to ListBox
                CourseList.Items.Add(row["CousreName"].ToString());
            }
        }
        private void CourseList_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCourse = CourseList.SelectedItem.ToString();
            string sql = "SELECT * FROM Courses WHERE CousreName = '" + Coursenameprtxt + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            GetData();
            LoadCourseList();
            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                Courseidtxt.Text = row["CourseId"].ToString();
                Coursenameprtxt.Text = row["CourseName"].ToString();
                Numbertxt.Text = row["TimeDuration"].ToString();
                Coursefeetxt.Text = row["Fees"].ToString();
            }
        }
           

        private void Addbtn_Click(object sender, EventArgs e)
        {
            if (Courseidtxt.Text != "" && Coursenameprtxt.Text != "" && Numbertxt.Text != "" && Coursefeetxt.Text != "")
            {

                String sql = "INSERT INTO Courses values( '" + Courseidtxt.Text + "', '" + Coursenameprtxt.Text + "','" + Numbertxt.Text + "',  '" + Coursefeetxt.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                GetData();
                LoadCourseList();
                if (aa == 0)
                {
                    MessageBox.Show("Course Recorde Successfully Added!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                }
                else
                {
                    MessageBox.Show("Record Not Found", "Add course", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("Please Enter Value", "Add course", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Courseidtxt.Focus();
            }

        }

        private void Deleteidbtn_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM Courses where CourseId = '" + Courseidtxt.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show("Course Record Deleted!", "Delete Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
            GetData();
            LoadCourseList();


        }

        private void Closebtn_Click(object sender, EventArgs e)
        {
            Student_Home student_Home = new Student_Home();
            student_Home.Show();
            this.Close();

        }
        private void Clear()
        {
            Courseidtxt.Text = "";
            Coursenameprtxt.Text = "";
            Coursefeetxt.Text = "";
            Numbertxt.Text = "";


            Courseidtxt.Focus();
        }

       
        private void ManageCourse_Load(object sender, EventArgs e)
        {
            LoadCourseList();
            // TODO: This line of code loads data into the 'student_management_system_CoursesDBDataSet1.Courses' table. You can move, or remove it, as needed.
            //this.coursesTableAdapter.Fill(this.student_management_system_CoursesDBDataSet1.Courses);
            this.CourseList.SelectedIndexChanged += new System.EventHandler(this.CourseList_SelectedIndexChanged);
            GetData();
        }
        private void GetData()
        {
            string sql = "SELECT * FROM Courses";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Ensure a valid row is clicked
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex]; // Access the clicked row
                Courseidtxt.Text = row.Cells[0].Value.ToString();
                Coursenameprtxt.Text = row.Cells[1].Value.ToString();
                Numbertxt.Text = row.Cells[2].Value.ToString();
                Coursefeetxt.Text = row.Cells[3].Value.ToString();
            }

        }

        private void comboBoxCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxCourse.SelectedItem != null)
            {
                string selectedCourse = comboBoxCourse.SelectedItem.ToString();
                Coursenameprtxt.Text = selectedCourse;

               
                GetData();
            }
        }
    }
}
