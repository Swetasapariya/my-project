﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;



namespace student_management_system
{
    public partial class Teacher_Details : Form
    {
        // SqlConnection cn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\student_management_systemDB.mdf;Integrated Security=True");
     
        public Teacher_Details()
        {
            InitializeComponent();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void Teacher_Details_Load(object sender, EventArgs e)
        {
           
            this.teachersTableAdapter.Fill(this.student_management_systemDBDataSet.Teachers);
           
            Loaddata();

        }
        //insert
        private void Adbtn_Click(object sender, EventArgs e)
        {
            int a = 0;
            if (idtxt.Text != "" && nametxt.Text != "" && subcheck.Text != "Select Subject" && qulitxt.Text != "")
            {
                string sql = "INSERT INTO Teachers values('" + idtxt.Text + "','" + nametxt.Text + "','" + subcheck.Text + "','" + qulitxt.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                Loaddata();
                if ( a == 0)
                {
                    MessageBox.Show("Teachers Records Inserted!","Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                }
                else
                {
                    MessageBox.Show("There Was Some Error!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please Enter Value", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                idtxt.Focus();
            }


        }

        

        private void Loaddata()
        {
            string sql = "select * from Teachers";
            SqlDataAdapter da = new SqlDataAdapter(sql,studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }
        //clear
        private void Clear()
        {
            idtxt.Text = "";
            nametxt.Text = "";
          
            subcheck.Text = "";
            
            qulitxt.Text = "";
            idtxt.Focus();
        }
       

        //update
        private void Updbtn_Click(object sender, EventArgs e)
        {
            //string value = dataGridView1.SelectedCells[0].Value.ToString();
            
                string sql = "UPDATE Teachers set teacher_name='" + nametxt.Text + "',subject='" + subcheck.Text + "',qualification = '" + qulitxt.Text + "' where Id='" + idtxt.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
               Loaddata();
          
                MessageBox.Show("Record Updated!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
           


        }

        private void Delbtn_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM Teachers where Id = '" + idtxt.Text +"'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Loaddata();
           
                MessageBox.Show("Record Deleted!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
         
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
           Student_Home H = new Student_Home();
            H.Show();   
          
            this.Close();
          
         
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0) // Ensure a valid row is clicked
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                idtxt.Text = row.Cells[0].Value.ToString();
                nametxt.Text = row.Cells[1].Value.ToString();
                subcheck.Text = row.Cells[2].Value.ToString();
                qulitxt.Text = row.Cells[3].Value.ToString();
            }

        }

      
        


        private void idtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
         

        }

        private void nametxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
          
        }

        private void qulitxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
           
        }
    }
}
