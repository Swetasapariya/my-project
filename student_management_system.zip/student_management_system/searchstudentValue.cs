﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace student_management_system
{
    public partial class searchstudentValue : Form
    {
        public searchstudentValue()
        {
            InitializeComponent();
        }

        String Gender;
        private void searchstudentValue_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'student_management_systemDBDataSet2.Student' table. You can move, or remove it, as needed.
            //this.studentTableAdapter.Fill(this.student_management_systemDBDataSet2.Student);
            Getdata();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void Addsbtn_Click(object sender, EventArgs e)
        {

            if (Gndrbtn.Checked)
            {
                Gender = "Male";

            }
            else if (Femrbtn.Checked)
            {
                Gender = "Female";
            }
            else
            {
                Gender = "Not select Gender";
            }
            int aa = 0;
            if (Idstxt.Text != "" && Studnmetxt.Text != "" && Gndrbtn.Text != "" && DateTimePicker1.Text != "" && Cntnmtxt.Text != "" && Pintxt.Text != "" && Citycombo.Text != "" && Adrestxt.Text != "")
            {
                String gender = Gndrbtn.Checked ? "Male" : Femrbtn.Checked ? "Female" : "Other";
                String sql = "INSERT INTO Student values( '" + Idstxt.Text + "', '" + Studnmetxt.Text + "','" + gender + "',  '" + DateTimePicker1.Text + "',  '" + Cntnmtxt.Text + "',  '" + Pintxt.Text + "', '" + Citycombo.Text + "', '" + Adrestxt.Text + "') ";
                SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                 Getdata();
                if (aa == 0)
                {
                    MessageBox.Show("Student Successfully Added!", "Add Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                }
                else
                {
                    MessageBox.Show("Student  Record Not Found", "Add Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("Please Enter Value");
                Idstxt.Focus();
            }

        }
        private void Clear()
        {
            Idstxt.Text = "";
            Studnmetxt.Text = "";
            Gndrbtn.Checked = false;
            Femrbtn.Checked = false;
         //   DateTimePicker1.Value = DateTime.Now;
            Cntnmtxt.Text = "";
            Pintxt.Text = "";
            Citycombo.SelectedIndex = -1; ;
            Adrestxt.Text = "";
            Idstxt.Focus();
        }
        private void Updatesbtn_Click(object sender, EventArgs e)
        {
            if (Gndrbtn.Checked)
            {
                Gender = "Male";

            }
            else if (Femrbtn.Checked)
            {
                Gender = "Female";
            }
            else
            {
                Gender = "Not select Gender";
            }
            // string gender = Gndrbtn.Checked ? "Male" : Femrbtn.Checked ? "Female" : "Other";
            if (string.IsNullOrWhiteSpace(Studnmetxt.Text))
            {
                MessageBox.Show("Please enter the student name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string sql = "UPDATE Student SET Student_Name = '" + Studnmetxt.Text + "', Gender = '" + Gender + "', Date_of_Birth = '" + DateTimePicker1.Text + "', Contact_Number = '" + Cntnmtxt.Text + "', Pin_Code = '" + Pintxt.Text + "', City = '" + Citycombo.Text + "', Address = '" + Adrestxt.Text + "'  where Student_Id='" + Idstxt.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Getdata();
            MessageBox.Show("Student Record Updated!", "Update Student", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }

        private void Deletesbtn_Click(object sender, EventArgs e)
        {

            string sql = "DELETE FROM Student where Student_Id = '" + Idstxt.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show("Student Record Deleted!", "Delete Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Getdata();
        }

        private void Getdata()
        {
            DateTimePicker1.MaxDate = DateTime.Now;

            string sql = "SELECT * from Student";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void Searchbtn_Click(object sender, EventArgs e)
        {
            /*string searchValue = Searchtxt.Text;
            string sql = "SELECT * FROM Student WHERE( Student_Id, Student_Name, Gender, Date_of_Birth, Contact_Number, Pin_Code, City, Address) LIKE '%" + Searchtxt.Text+"%'";
            SqlDataAdapter da = new SqlDataAdapter(sql,studentclass.cn);
            
            DataTable dt = new DataTable();
            da.Fill(dt);*/
            string sql = "SELECT Student_Id, Student_Name, Gender, Date_of_Birth, Contact_Number, Pin_Code, City, Address FROM Student WHERE Student_Id = '" + Searchtxt.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                Idstxt.Text = row["Student_Id"].ToString();
                Studnmetxt.Text = row["Student_Name"].ToString();
                DateTimePicker1.Value = Convert.ToDateTime(row["Date_of_Birth"]);
                Cntnmtxt.Text = row["Contact_Number"].ToString();
                Pintxt.Text = row["Pin_Code"].ToString();
                Citycombo.Text = row["City"].ToString();
                Adrestxt.Text = row["Address"].ToString();

                // Reset gender radio buttons
                Gndrbtn.Checked = false;
                Femrbtn.Checked = false;

                // Set the gender based on the retrieved data
                string gender = row["Gender"].ToString();
                if (gender.Equals("Male", StringComparison.OrdinalIgnoreCase))
                {
                    Gndrbtn.Checked = true;
                }
                else if (gender.Equals("Female", StringComparison.OrdinalIgnoreCase))
                {
                    Femrbtn.Checked = true;
                }
            }
            else
            {
                MessageBox.Show("No records found for the provided Student ID.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
            }


        }

        private void Resrtbtn_Click(object sender, EventArgs e)
        {
            Clear();
            Getdata();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                Idstxt.Text = row.Cells[0].Value.ToString();
                Studnmetxt.Text = row.Cells[1].Value.ToString();
                Gender = row.Cells[2].Value.ToString();
                DateTimePicker1.Text = row.Cells[3].Value.ToString();
                Cntnmtxt.Text = row.Cells[4].Value.ToString();
                Pintxt.Text = row.Cells[5].Value.ToString();
                Citycombo.Text = row.Cells[6].Value.ToString();
                Adrestxt.Text = row.Cells[7].Value.ToString();
               
            }
        }

      
        private void Btnbkh_Click(object sender, EventArgs e)
        {
            Student_Home student = new Student_Home();
            student.Show();
            this.Close();

        }
    }
}
