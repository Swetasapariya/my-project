﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management_system
{
    public partial class Student_Home : Form
    {
        public Student_Home()
        {
            InitializeComponent();
        }

        
      
        private void Student_Home_Load(object sender, EventArgs e)
        {
           
            

        }

        private void TeacherDetailbtn_Click(object sender, EventArgs e)
        {
            Teacher_Details t = new Teacher_Details();
            t.Show();
            this.Hide();
            

        }

        private void Studdetbtn_Click(object sender, EventArgs e)
        {
            Student_Details student = new Student_Details();
            student.Show();
            this.Hide();
        }

        private void Edstudbtn_Click(object sender, EventArgs e)
        {

            SearchStudents ss = new SearchStudents();
            ss.Show();
            this.Hide();

        }

        private void Managestudbtn_Click(object sender, EventArgs e)
        {
            searchstudentValue ssv = new searchstudentValue();
            ssv.Show();
            this.Hide();


        }

        private void listStudbtn_Click(object sender, EventArgs e)
        {

            Studentlist sl = new Studentlist();
            sl.Show();
            this.Hide();
        }

        private void Printstudrebtn_Click(object sender, EventArgs e)
        {
            PrintRecStudent prs = new PrintRecStudent();
            prs.Show();
            this.Hide();
        }

        private void Addcdbtn_Click(object sender, EventArgs e)
        {
          //  studentclass.menuitem = 1;
            AddCourse ac = new AddCourse();
            ac.Show();
            this.Hide();
        }

        private void Ercbtn_Click(object sender, EventArgs e)
        {
            EditDeleteCourse edc = new EditDeleteCourse();
            edc.Show();
            this.Hide();

        }

        private void Mancoursebtn_Click(object sender, EventArgs e)
        {
            ManageCourse mc = new ManageCourse();
            mc.Show();
            this.Hide();
        }

        private void FeesDetails_Click(object sender, EventArgs e)
        {
            Fees f = new Fees();
            f.Show();
            this.Hide();


        }

        private void cncbtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you wan to exit", "Cancle", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you wan to Log Out", "LogOut", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }


        }
    }
}
