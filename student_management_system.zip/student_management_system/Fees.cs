﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace student_management_system
{
    public partial class Fees : Form
    {
        public Fees()
        {
            InitializeComponent();
            Paidfeestxt.TextChanged += Paidfeestxt_TextChanged;
            Finalpaidfeesbtn.Click += Finalpaidfeesbtn_Click;

        }

     
        private void InitializeFeesDataTable()
        {

            string sql = "SELECT * from Fees";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            //dataGridViewFees.DataSource = dt;
        }



       


        private void Printfees_Click(object sender, EventArgs e)
        {
            

            string pdfPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "FeesReport.pdf");

            using (FileStream fs = new FileStream(pdfPath, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                Document document = new Document();
                PdfWriter.GetInstance(document, fs);
                document.Open();

                document.Add(new Paragraph("Fees Report"));
                document.Add(new Paragraph($"Student ID: {Idstxt.Text}"));
                document.Add(new Paragraph($"Student Name: {Studnmetxt.Text}"));
                document.Add(new Paragraph($"Course Name: {CourseName.Text}"));
                document.Add(new Paragraph($"Total Fees: {Coursefeetxt.Text}"));
                document.Add(new Paragraph($"Paid Fees: {Paidfeestxt.Text}"));
                document.Add(new Paragraph($"Remaining Fees: {Remainfeestxt.Text}"));
                document.Add(new Paragraph($"Final Paid Fees: {Finalpaidfeestxt.Text}"));

                document.Close();
                MessageBox.Show($"PDF generated successfully at {pdfPath}.");
            }



        }

       

        private void Fees_Load(object sender, EventArgs e)
        {
            
            InitializeFeesDataTable();
            Getdata();
            LoadCourses();
           

        }

     

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count >= 0)
            {
                var row = dataGridView1.SelectedRows[0];
                Idstxt.Text = row.Cells[0].Value.ToString();
                Studnmetxt.Text = row.Cells[1].Value.ToString();
                // You can also handle loading course-related info if necessary
            }
        }
        private void LoadCourses()
        {
            
          
                string sql = "SELECT  CousreName,Fees FROM Courses"; // Adjust the query if needed
                SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                // The value to use as the selected value
                CourseDataGridView .DataSource = dt;
        }
        private void Getdata()
        {
            

            string sql = "SELECT * from Student";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }
        private void ConfigureCourseDataGridView()
        {
            CourseDataGridView.AutoGenerateColumns = false; // Disable auto-generation of columns

            
            CourseDataGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "CourseName",
                DataPropertyName = "CourseName",
                ReadOnly = true
            });
            CourseDataGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Fees",
                DataPropertyName = "Fees",
                ReadOnly = true
            });
        }

        private void CourseDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (CourseDataGridView.SelectedRows.Count > 0)
            {
                var row = CourseDataGridView.SelectedRows[0];
                CourseName.Text = row.Cells[0].Value.ToString();
                Coursefeetxt.Text = row.Cells[1].Value.ToString();
            }
           
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            Student_Home shome = new Student_Home();
            shome.Show();
            this.Hide();

        }

        private void Finalpaidfeesbtn_Click(object sender, EventArgs e)
        {
            if (double.TryParse(Remainfeestxt.Text, out double remainingFee) && double.TryParse(Finalpaidfeestxt.Text, out double finalPaidFee))
            {
                if (finalPaidFee >= remainingFee)
                {
                    MessageBox.Show("Payment successful!");
                 //   InsertFeesIntoDatabase(); // Ensure this method exists and works correctly
                }
                else
                {
                    MessageBox.Show("Final paid fee is less than the remaining fee. Please complete the full payment.");
                }
            }
            else
            {
                MessageBox.Show("Invalid fee input. Please enter valid numbers.");
            }
        }

        private void Paidfeestxt_TextChanged(object sender, EventArgs e)
        {
         
                double courseFee = 0;
                double paidFee = 0;

                // Try to parse the Course Fee (this should already be filled with a valid number)
                if (!double.TryParse(Coursefeetxt.Text, out courseFee))
                {
                    MessageBox.Show("Invalid course fee. Please enter a valid number.");
                    return;
                }

                // Try to parse the Paid Fee from the textbox
                if (double.TryParse(Paidfeestxt.Text, out paidFee))
                {
                    // Calculate the remaining fee
                    double remainingFee = courseFee - paidFee;

                    // Display the remaining fee in the textbox
                    Remainfeestxt.Text = remainingFee.ToString("F2");
                }
                else
                {
                    // Clear the Remaining Fee textbox if the Paid Fee input is invalid
                    Remainfeestxt.Text = string.Empty;
                }
            
        }

     
    }
}
    


