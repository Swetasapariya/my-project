﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management_system
{
    public partial class AddCourse : Form
    {
        public AddCourse()
        {
            InitializeComponent();
        }
        int aa = 0;
        
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void Addbtn_Click(object sender, EventArgs e)
        {
            if (Courseidtxt.Text != "" && CourseName.Text != "" && Numbertxt.Text != "" && Coursefeetxt.Text != "" )
            {
                

                String sql = "INSERT INTO Courses values( '" + Courseidtxt.Text + "', '" + CourseName.Text + "','" + Numbertxt.Text + "',  '" + Coursefeetxt.Text + "' )";
                SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                //  Getdata();
                if (aa == 0)
                {
                    MessageBox.Show("Course Recorde Successfully Added!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                }
                else
                {
                    MessageBox.Show("Record Not Found", "Add course", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("Please Enter Value", "Add course", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Courseidtxt.Focus();
            }

        }
        private void Clear()
        {
            Courseidtxt.Text = "";
            CourseName.SelectedIndex = -1; 
            Coursefeetxt.Text = "";
            Numbertxt.Text = "";
            

           Courseidtxt.Focus();
        }

        private void Closebtn_Click(object sender, EventArgs e)
        {
            Student_Home stud = new Student_Home();
            stud.Show();
            this.Close();
        }

        private void AddCourse_Load(object sender, EventArgs e)
        {

        }

      

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Courseidtxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Courseidtxt.Text) == true)
            {
                errorProvider1.SetError(this.Courseidtxt, "Please Enter Student Name");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void Coursefeetxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Courseidtxt.Text) == true)
            {
                errorProvider1.SetError(this.Courseidtxt, "Please Enter Student Name");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void Courseidtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
          
        }

        private void Coursefeetxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
          
        }
    }
}
