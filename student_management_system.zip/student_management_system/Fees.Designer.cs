﻿namespace student_management_system
{
    partial class Fees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Backbtn = new System.Windows.Forms.Button();
            this.Finalpaidfeestxt = new System.Windows.Forms.TextBox();
            this.Remainfeestxt = new System.Windows.Forms.TextBox();
            this.Paidfeestxt = new System.Windows.Forms.TextBox();
            this.Printfees = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Coursefeetxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.CourseName = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Studnmetxt = new System.Windows.Forms.TextBox();
            this.Idstxt = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.studentIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.student_management_systemDBDataSet2 = new student_management_system.student_management_systemDBDataSet2();
            this.studentTableAdapter = new student_management_system.student_management_systemDBDataSet2TableAdapters.StudentTableAdapter();
            this.CourseDataGridView = new System.Windows.Forms.DataGridView();
            this.cousreNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.feesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coursesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.student_management_system_CoursesDBDataSet1 = new student_management_system.student_management_system_CoursesDBDataSet1();
            this.coursesTableAdapter = new student_management_system.student_management_system_CoursesDBDataSet1TableAdapters.CoursesTableAdapter();
            this.feesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.student_management_systemDBDataSet1 = new student_management_system.student_management_systemDBDataSet1();
            this.feesTableAdapter = new student_management_system.student_management_systemDBDataSet1TableAdapters.FeesTableAdapter();
            this.Finalpaidfeesbtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_management_systemDBDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CourseDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coursesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_management_system_CoursesDBDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.feesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_management_systemDBDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Finalpaidfeesbtn);
            this.groupBox1.Controls.Add(this.Backbtn);
            this.groupBox1.Controls.Add(this.Finalpaidfeestxt);
            this.groupBox1.Controls.Add(this.Remainfeestxt);
            this.groupBox1.Controls.Add(this.Paidfeestxt);
            this.groupBox1.Controls.Add(this.Printfees);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Coursefeetxt);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.CourseName);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Studnmetxt);
            this.groupBox1.Controls.Add(this.Idstxt);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(734, 522);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // Backbtn
            // 
            this.Backbtn.BackColor = System.Drawing.Color.BlueViolet;
            this.Backbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Backbtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Backbtn.Location = new System.Drawing.Point(265, 444);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.Size = new System.Drawing.Size(180, 43);
            this.Backbtn.TabIndex = 83;
            this.Backbtn.Text = "Back";
            this.Backbtn.UseVisualStyleBackColor = false;
            this.Backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // Finalpaidfeestxt
            // 
            this.Finalpaidfeestxt.Location = new System.Drawing.Point(320, 376);
            this.Finalpaidfeestxt.Name = "Finalpaidfeestxt";
            this.Finalpaidfeestxt.Size = new System.Drawing.Size(360, 22);
            this.Finalpaidfeestxt.TabIndex = 82;
            // 
            // Remainfeestxt
            // 
            this.Remainfeestxt.Location = new System.Drawing.Point(320, 331);
            this.Remainfeestxt.Name = "Remainfeestxt";
            this.Remainfeestxt.Size = new System.Drawing.Size(360, 22);
            this.Remainfeestxt.TabIndex = 81;
            // 
            // Paidfeestxt
            // 
            this.Paidfeestxt.Location = new System.Drawing.Point(320, 281);
            this.Paidfeestxt.Name = "Paidfeestxt";
            this.Paidfeestxt.Size = new System.Drawing.Size(363, 22);
            this.Paidfeestxt.TabIndex = 80;
            this.Paidfeestxt.TextChanged += new System.EventHandler(this.Paidfeestxt_TextChanged);
            // 
            // Printfees
            // 
            this.Printfees.BackColor = System.Drawing.Color.BlueViolet;
            this.Printfees.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Printfees.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Printfees.ForeColor = System.Drawing.SystemColors.Control;
            this.Printfees.Location = new System.Drawing.Point(36, 441);
            this.Printfees.Name = "Printfees";
            this.Printfees.Size = new System.Drawing.Size(172, 46);
            this.Printfees.TabIndex = 79;
            this.Printfees.Text = "Print";
            this.Printfees.UseVisualStyleBackColor = false;
            this.Printfees.Click += new System.EventHandler(this.Printfees_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(53, 387);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 20);
            this.label7.TabIndex = 77;
            this.label7.Text = "Final Paid Fee";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(53, 331);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 20);
            this.label6.TabIndex = 76;
            this.label6.Text = "Remaining Fees";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(73, 272);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 20);
            this.label2.TabIndex = 75;
            this.label2.Text = " Fees  Paid";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Coursefeetxt
            // 
            this.Coursefeetxt.Location = new System.Drawing.Point(320, 212);
            this.Coursefeetxt.Name = "Coursefeetxt";
            this.Coursefeetxt.Size = new System.Drawing.Size(363, 22);
            this.Coursefeetxt.TabIndex = 74;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(65, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 20);
            this.label5.TabIndex = 73;
            this.label5.Text = "Course Fees";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // CourseName
            // 
            this.CourseName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CourseName.FormattingEnabled = true;
            this.CourseName.Items.AddRange(new object[] {
            "C language",
            "C++",
            "C#",
            "PHP",
            "Python",
            "Java",
            "Javascript",
            "Andorid",
            "Asp.Net"});
            this.CourseName.Location = new System.Drawing.Point(323, 155);
            this.CourseName.Name = "CourseName";
            this.CourseName.Size = new System.Drawing.Size(360, 24);
            this.CourseName.TabIndex = 72;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 20);
            this.label1.TabIndex = 71;
            this.label1.Text = "Course Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(73, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 66;
            this.label3.Text = " Student Id";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(53, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 20);
            this.label4.TabIndex = 67;
            this.label4.Text = "Student Name";
            // 
            // Studnmetxt
            // 
            this.Studnmetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Studnmetxt.Location = new System.Drawing.Point(320, 99);
            this.Studnmetxt.Name = "Studnmetxt";
            this.Studnmetxt.Size = new System.Drawing.Size(360, 24);
            this.Studnmetxt.TabIndex = 69;
            // 
            // Idstxt
            // 
            this.Idstxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Idstxt.Location = new System.Drawing.Point(323, 37);
            this.Idstxt.Name = "Idstxt";
            this.Idstxt.Size = new System.Drawing.Size(360, 24);
            this.Idstxt.TabIndex = 68;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentIdDataGridViewTextBoxColumn,
            this.studentNameDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.studentBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(767, 262);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(374, 189);
            this.dataGridView1.TabIndex = 70;
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // studentIdDataGridViewTextBoxColumn
            // 
            this.studentIdDataGridViewTextBoxColumn.DataPropertyName = "Student_Id";
            this.studentIdDataGridViewTextBoxColumn.HeaderText = "Student_Id";
            this.studentIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.studentIdDataGridViewTextBoxColumn.Name = "studentIdDataGridViewTextBoxColumn";
            // 
            // studentNameDataGridViewTextBoxColumn
            // 
            this.studentNameDataGridViewTextBoxColumn.DataPropertyName = "Student_Name";
            this.studentNameDataGridViewTextBoxColumn.HeaderText = "Student_Name";
            this.studentNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.studentNameDataGridViewTextBoxColumn.Name = "studentNameDataGridViewTextBoxColumn";
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "Student";
            this.studentBindingSource.DataSource = this.student_management_systemDBDataSet2;
            // 
            // student_management_systemDBDataSet2
            // 
            this.student_management_systemDBDataSet2.DataSetName = "student_management_systemDBDataSet2";
            this.student_management_systemDBDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // CourseDataGridView
            // 
            this.CourseDataGridView.AutoGenerateColumns = false;
            this.CourseDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CourseDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CourseDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cousreNameDataGridViewTextBoxColumn,
            this.feesDataGridViewTextBoxColumn});
            this.CourseDataGridView.DataSource = this.coursesBindingSource;
            this.CourseDataGridView.Location = new System.Drawing.Point(767, 31);
            this.CourseDataGridView.Name = "CourseDataGridView";
            this.CourseDataGridView.RowHeadersVisible = false;
            this.CourseDataGridView.RowHeadersWidth = 51;
            this.CourseDataGridView.RowTemplate.Height = 24;
            this.CourseDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CourseDataGridView.Size = new System.Drawing.Size(403, 189);
            this.CourseDataGridView.TabIndex = 71;
            this.CourseDataGridView.SelectionChanged += new System.EventHandler(this.CourseDataGridView_SelectionChanged);
            // 
            // cousreNameDataGridViewTextBoxColumn
            // 
            this.cousreNameDataGridViewTextBoxColumn.DataPropertyName = "CousreName";
            this.cousreNameDataGridViewTextBoxColumn.HeaderText = "CousreName";
            this.cousreNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cousreNameDataGridViewTextBoxColumn.Name = "cousreNameDataGridViewTextBoxColumn";
            // 
            // feesDataGridViewTextBoxColumn
            // 
            this.feesDataGridViewTextBoxColumn.DataPropertyName = "Fees";
            this.feesDataGridViewTextBoxColumn.HeaderText = "Fees";
            this.feesDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.feesDataGridViewTextBoxColumn.Name = "feesDataGridViewTextBoxColumn";
            // 
            // coursesBindingSource
            // 
            this.coursesBindingSource.DataMember = "Courses";
            this.coursesBindingSource.DataSource = this.student_management_system_CoursesDBDataSet1;
            // 
            // student_management_system_CoursesDBDataSet1
            // 
            this.student_management_system_CoursesDBDataSet1.DataSetName = "student_management_system_CoursesDBDataSet1";
            this.student_management_system_CoursesDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // coursesTableAdapter
            // 
            this.coursesTableAdapter.ClearBeforeFill = true;
            // 
            // feesBindingSource
            // 
            this.feesBindingSource.DataMember = "Fees";
            this.feesBindingSource.DataSource = this.student_management_systemDBDataSet1;
            // 
            // student_management_systemDBDataSet1
            // 
            this.student_management_systemDBDataSet1.DataSetName = "student_management_systemDBDataSet1";
            this.student_management_systemDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // feesTableAdapter
            // 
            this.feesTableAdapter.ClearBeforeFill = true;
            // 
            // Finalpaidfeesbtn
            // 
            this.Finalpaidfeesbtn.BackColor = System.Drawing.Color.BlueViolet;
            this.Finalpaidfeesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Finalpaidfeesbtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Finalpaidfeesbtn.Location = new System.Drawing.Point(483, 441);
            this.Finalpaidfeesbtn.Name = "Finalpaidfeesbtn";
            this.Finalpaidfeesbtn.Size = new System.Drawing.Size(180, 43);
            this.Finalpaidfeesbtn.TabIndex = 84;
            this.Finalpaidfeesbtn.Text = "Paid";
            this.Finalpaidfeesbtn.UseVisualStyleBackColor = false;
//            this.Finalpaidfeesbtn.TextChanged += new System.EventHandler(this.Finalpaidfeesbtn_TextChanged);
            this.Finalpaidfeesbtn.Click += new System.EventHandler(this.Finalpaidfeesbtn_Click);
            // 
            // Fees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1197, 582);
            this.Controls.Add(this.CourseDataGridView);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Fees";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fees";
            this.Load += new System.EventHandler(this.Fees_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_management_systemDBDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CourseDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coursesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_management_system_CoursesDBDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.feesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_management_systemDBDataSet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        internal System.Windows.Forms.TextBox Studnmetxt;
        internal System.Windows.Forms.TextBox Idstxt;
        private System.Windows.Forms.ComboBox CourseName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Coursefeetxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Printfees;
        private System.Windows.Forms.TextBox Finalpaidfeestxt;
        private System.Windows.Forms.TextBox Remainfeestxt;
        private System.Windows.Forms.TextBox Paidfeestxt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private student_management_systemDBDataSet2 student_management_systemDBDataSet2;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private student_management_systemDBDataSet2TableAdapters.StudentTableAdapter studentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView CourseDataGridView;
        private student_management_system_CoursesDBDataSet1 student_management_system_CoursesDBDataSet1;
        private System.Windows.Forms.BindingSource coursesBindingSource;
        private student_management_system_CoursesDBDataSet1TableAdapters.CoursesTableAdapter coursesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn cousreNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn feesDataGridViewTextBoxColumn;
        private student_management_systemDBDataSet1 student_management_systemDBDataSet1;
        private System.Windows.Forms.BindingSource feesBindingSource;
        private student_management_systemDBDataSet1TableAdapters.FeesTableAdapter feesTableAdapter;
        private System.Windows.Forms.Button Backbtn;
        private System.Windows.Forms.Button Finalpaidfeesbtn;
    }
}