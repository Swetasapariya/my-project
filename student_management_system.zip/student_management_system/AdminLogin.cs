﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management_system
{
    public partial class AdminLogin : Form
    {
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void cncbtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you wan to exit", "Cancle", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void usrtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void pswdtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void pwdcek_CheckedChanged(object sender, EventArgs e)
        {
            if (pwdcek.Checked == true)
            {
                pswdtxt.UseSystemPasswordChar = false;
            }
            else
            {
                pswdtxt.UseSystemPasswordChar = true;
            }

        }

        private void clrbtn_Click(object sender, EventArgs e)
        {
            usrtxt.Clear();
            pswdtxt.Clear();
        }

        private void adloginbtn_Click(object sender, EventArgs e)
        {
            if (usrtxt.Text != "" && pswdtxt.Text != "")
            {
                string sql = "select * from admin_login where username ='" + usrtxt.Text + "' and password='" + pswdtxt.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 1)
                {

                    Student_Home h = new Student_Home();
                    h.Show();
                    this.Hide();
                }
                else
                {
                    clr();
                }


            }
            else
            {
                clr();
            }
        }
        private void clr()
        {
            MessageBox.Show("Enter!", "App", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            usrtxt.Text = pswdtxt.Text = string.Empty;
            usrtxt.Focus();
        }

        private void AdminLogin_Load(object sender, EventArgs e)
        {

        }

        private void usrtxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(usrtxt.Text))
            {
                usrtxt.Focus();
                errorProvider1.SetError(this.usrtxt, "Please Enter User Name");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void pswdtxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(pswdtxt.Text))
            {
                pswdtxt.Focus();
                errorProvider1.SetError(this.pswdtxt, "Please Enter User Name");
            }
            else
            {
                errorProvider1.Clear();
            }

        }

        private void usrtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
          
        }

        private void pswdtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetterOrDigit(e.KeyChar))
            {
                e.Handled = true;
            }
          

        }
    }
}
