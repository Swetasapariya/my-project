﻿namespace student_management_system
{
    partial class Student_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Addsbtn = new System.Windows.Forms.Button();
            this.Idstxt = new System.Windows.Forms.TextBox();
            this.Studnmetxt = new System.Windows.Forms.TextBox();
            this.Cntnmtxt = new System.Windows.Forms.TextBox();
            this.Pintxt = new System.Windows.Forms.TextBox();
            this.Adrestxt = new System.Windows.Forms.TextBox();
            this.Gndrbtn = new System.Windows.Forms.RadioButton();
            this.Femrbtn = new System.Windows.Forms.RadioButton();
            this.DateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Citycombo = new System.Windows.Forms.ComboBox();
            this.studentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Btnbkh = new System.Windows.Forms.Button();
            this.Closebtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(78, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = " Student Id";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(63, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Student Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(71, 324);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Gender";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(55, 387);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 20);
            this.label8.TabIndex = 6;
            this.label8.Text = "Date Of Birth";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(56, 208);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 20);
            this.label9.TabIndex = 7;
            this.label9.Text = "Contact Number";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(71, 462);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 20);
            this.label10.TabIndex = 8;
            this.label10.Text = "Pin Code";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(71, 268);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 20);
            this.label12.TabIndex = 10;
            this.label12.Text = "City";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(63, 529);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 20);
            this.label14.TabIndex = 12;
            this.label14.Text = "Address";
            // 
            // Addsbtn
            // 
            this.Addsbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Addsbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addsbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addsbtn.ForeColor = System.Drawing.Color.SkyBlue;
            this.Addsbtn.Location = new System.Drawing.Point(25, 624);
            this.Addsbtn.Name = "Addsbtn";
            this.Addsbtn.Size = new System.Drawing.Size(165, 40);
            this.Addsbtn.TabIndex = 14;
            this.Addsbtn.Text = "Add";
            this.Addsbtn.UseVisualStyleBackColor = false;
            this.Addsbtn.Click += new System.EventHandler(this.Addsbtn_Click);
            // 
            // Idstxt
            // 
            this.Idstxt.Location = new System.Drawing.Point(242, 90);
            this.Idstxt.Name = "Idstxt";
            this.Idstxt.Size = new System.Drawing.Size(349, 22);
            this.Idstxt.TabIndex = 19;
            this.Idstxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Idstxt_KeyPress);
            // 
            // Studnmetxt
            // 
            this.Studnmetxt.Location = new System.Drawing.Point(242, 145);
            this.Studnmetxt.Name = "Studnmetxt";
            this.Studnmetxt.Size = new System.Drawing.Size(349, 22);
            this.Studnmetxt.TabIndex = 20;
            this.Studnmetxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Studnmetxt_KeyPress);
            this.Studnmetxt.Leave += new System.EventHandler(this.Studnmetxt_Leave);
            // 
            // Cntnmtxt
            // 
            this.Cntnmtxt.Location = new System.Drawing.Point(242, 206);
            this.Cntnmtxt.MaxLength = 10;
            this.Cntnmtxt.Name = "Cntnmtxt";
            this.Cntnmtxt.Size = new System.Drawing.Size(349, 22);
            this.Cntnmtxt.TabIndex = 25;
            this.Cntnmtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Cntnmtxt_KeyPress);
            this.Cntnmtxt.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Cntnmtxt_KeyUp);
            // 
            // Pintxt
            // 
            this.Pintxt.Location = new System.Drawing.Point(242, 462);
            this.Pintxt.MaxLength = 6;
            this.Pintxt.Name = "Pintxt";
            this.Pintxt.Size = new System.Drawing.Size(349, 22);
            this.Pintxt.TabIndex = 26;
            this.Pintxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Pintxt_KeyPress);
            this.Pintxt.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Pintxt_KeyUp);
            // 
            // Adrestxt
            // 
            this.Adrestxt.Location = new System.Drawing.Point(242, 510);
            this.Adrestxt.Multiline = true;
            this.Adrestxt.Name = "Adrestxt";
            this.Adrestxt.Size = new System.Drawing.Size(349, 92);
            this.Adrestxt.TabIndex = 31;
            // 
            // Gndrbtn
            // 
            this.Gndrbtn.AutoSize = true;
            this.Gndrbtn.Checked = true;
            this.Gndrbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Gndrbtn.Location = new System.Drawing.Point(251, 325);
            this.Gndrbtn.Name = "Gndrbtn";
            this.Gndrbtn.Size = new System.Drawing.Size(61, 20);
            this.Gndrbtn.TabIndex = 32;
            this.Gndrbtn.TabStop = true;
            this.Gndrbtn.Text = "Male";
            this.Gndrbtn.UseVisualStyleBackColor = true;
            // 
            // Femrbtn
            // 
            this.Femrbtn.AutoSize = true;
            this.Femrbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Femrbtn.Location = new System.Drawing.Point(381, 325);
            this.Femrbtn.Name = "Femrbtn";
            this.Femrbtn.Size = new System.Drawing.Size(79, 20);
            this.Femrbtn.TabIndex = 33;
            this.Femrbtn.Text = "Female";
            this.Femrbtn.UseVisualStyleBackColor = true;
            // 
            // DateTimePicker1
            // 
            this.DateTimePicker1.Location = new System.Drawing.Point(242, 403);
            this.DateTimePicker1.MaxDate = new System.DateTime(2024, 10, 2, 0, 0, 0, 0);
            this.DateTimePicker1.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.DateTimePicker1.Name = "DateTimePicker1";
            this.DateTimePicker1.Size = new System.Drawing.Size(349, 22);
            this.DateTimePicker1.TabIndex = 34;
            this.DateTimePicker1.Value = new System.DateTime(2024, 10, 2, 0, 0, 0, 0);
            // 
            // Citycombo
            // 
            this.Citycombo.FormattingEnabled = true;
            this.Citycombo.Items.AddRange(new object[] {
            "Rajkot",
            "Ahmadabad",
            "Baroda",
            "Surat",
            "Junagadh",
            "Jamnager",
            "Anand",
            "Kach",
            "Veraval",
            "Surendranager"});
            this.Citycombo.Location = new System.Drawing.Point(242, 268);
            this.Citycombo.Name = "Citycombo";
            this.Citycombo.Size = new System.Drawing.Size(349, 24);
            this.Citycombo.TabIndex = 35;
            // 
            // studentsBindingSource
            // 
            this.studentsBindingSource.DataMember = "Students";
            // 
            // Btnbkh
            // 
            this.Btnbkh.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btnbkh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btnbkh.ForeColor = System.Drawing.Color.Red;
            this.Btnbkh.Location = new System.Drawing.Point(439, 624);
            this.Btnbkh.Name = "Btnbkh";
            this.Btnbkh.Size = new System.Drawing.Size(152, 40);
            this.Btnbkh.TabIndex = 39;
            this.Btnbkh.Text = "Back";
            this.Btnbkh.UseVisualStyleBackColor = false;
            this.Btnbkh.Click += new System.EventHandler(this.Btnbkh_Click);
            // 
            // Closebtn
            // 
            this.Closebtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Closebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Closebtn.ForeColor = System.Drawing.Color.LimeGreen;
            this.Closebtn.Location = new System.Drawing.Point(219, 624);
            this.Closebtn.Name = "Closebtn";
            this.Closebtn.Size = new System.Drawing.Size(167, 40);
            this.Closebtn.TabIndex = 40;
            this.Closebtn.Text = "Close";
            this.Closebtn.UseVisualStyleBackColor = false;
            this.Closebtn.Click += new System.EventHandler(this.Closebtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(196, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(317, 30);
            this.label1.TabIndex = 16;
            this.label1.Text = "Students Details";
            // 
            // Student_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(618, 676);
            this.Controls.Add(this.Closebtn);
            this.Controls.Add(this.Btnbkh);
            this.Controls.Add(this.Pintxt);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Adrestxt);
            this.Controls.Add(this.DateTimePicker1);
            this.Controls.Add(this.Addsbtn);
            this.Controls.Add(this.Citycombo);
            this.Controls.Add(this.Femrbtn);
            this.Controls.Add(this.Gndrbtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Cntnmtxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Idstxt);
            this.Controls.Add(this.Studnmetxt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label14);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Student_Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student_Details";
            this.Load += new System.EventHandler(this.Student_Details_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ComboBox Citycombo;
        private System.Windows.Forms.DateTimePicker DateTimePicker1;
        private System.Windows.Forms.RadioButton Femrbtn;
        private System.Windows.Forms.RadioButton Gndrbtn;
        private System.Windows.Forms.TextBox Adrestxt;
        private System.Windows.Forms.TextBox Pintxt;
        private System.Windows.Forms.TextBox Cntnmtxt;
        private System.Windows.Forms.TextBox Studnmetxt;
        private System.Windows.Forms.TextBox Idstxt;
        private System.Windows.Forms.Button Addsbtn;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
       // private student_management_systemDBDataSet1 student_management_systemDBDataSet1;
        private System.Windows.Forms.BindingSource studentsBindingSource;
       // private student_management_systemDBDataSet1TableAdapters.StudentsTableAdapter studentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Closebtn;
        private System.Windows.Forms.Button Btnbkh;
        private System.Windows.Forms.Label label1;
    }
}