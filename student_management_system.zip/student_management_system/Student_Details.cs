﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace student_management_system
{
    public partial class Student_Details : Form
    {
        //String ispinvalidate = "N";
        //String iscntvalidate = "N";

        String Gender;
        int aa = 0;
        //String Id = String.Empty;
       // String patten = (@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

        public Student_Details()
        {
            InitializeComponent();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }


        private void Student_Details_Load(object sender, EventArgs e)
        {
            // Getdata();


        }

        //add students ......................................

        private void Addsbtn_Click(object sender, EventArgs e)
        {

            if (Gndrbtn.Checked)
            {
                Gender = "Male";

            }
            else if (Femrbtn.Checked)
            {
                Gender = "Female";
            }
            else
            {
                Gender = "Not select Gender";
            }

            if (Idstxt.Text != "" && Studnmetxt.Text != "" && Gndrbtn.Text != "" && DateTimePicker1.Text != "" && Cntnmtxt.Text != "" && Pintxt.Text != "" && Citycombo.Text != "" && Adrestxt.Text != "" )
            {
                String gender = Gndrbtn.Checked ? "Male" : Femrbtn.Checked ? "Female" : "Other";
                String sql = "INSERT INTO Student values( '" + Idstxt.Text + "', '" + Studnmetxt.Text + "','" + gender + "',  '" + DateTimePicker1.Text + "',  '" + Cntnmtxt.Text + "',  '" + Pintxt.Text + "', '" + Citycombo.Text + "', '" + Adrestxt.Text + "') ";
                SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                //  Getdata();
                if (aa == 0)
                {
                    MessageBox.Show("Student Successfully Added!" ,"Add Student",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    Clear();
                }
                else
                {
                    MessageBox.Show("Student  Record Not Found", "Add Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("Please Enter Value","Add Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Idstxt.Focus();
            }

        }
        /*  private void Getdata()
          {
              DateTimePicker1.MaxDate = DateTime.Now;

              string sql = "SELECT * from Students";
               SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
              DataTable dt = new DataTable();
              da.Fill(dt);
              //dataGridView1.DataSource = dt;

          }*/

        //update.................

        /*  private void Updatesbtn_Click(object sender, EventArgs e)
          {
         // string sql = "SELECT * FROM Students  WHERE Id = '" + idstxt.Text + "'"; 

              string sql = "UPDATE Students SET [Student Name] = '" + Studnmetxt.Text + "', Gender = '" + Gender + "', [Date of Birth] = '" + DateTimePicker1.Text + "', [Contact Number] = '" + Cntnmtxt.Text + "', [Pin Code] = '" + Pintxt.Text + "', City = '" + Citycombo.Text + "', Address = '" + Adrestxt.Text + "', Email = '" + Emltxt.Text + "'  where Student_Id='" + Idstxt.Text + "'";
              SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
              DataTable dt = new DataTable();
              da.Fill(dt);
              Getdata();
              MessageBox.Show("Record Updated!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);


          }*/

        //delete students.........................

        /*private void Deletesbtn_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM Students where Student_Id = '" + Idstxt.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Getdata();
            MessageBox.Show("Record Deleted!");
        }
        */
        private void Pintxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Pintxt_KeyUp(object sender, KeyEventArgs e)
        {
            String Ispinvalidate = "N";
            if (Pintxt.Text.Length < 6)
            {
                Pintxt.ForeColor = Color.Red;

            }
            else
            {
                Pintxt.ForeColor = Color.Green;

                Ispinvalidate = "Y";
            }

        }


        private void Cntnmtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Cntnmtxt_KeyUp(object sender, KeyEventArgs e)
        {
            String Iscntvalidate = "N";
            if (Cntnmtxt.Text.Length < 10)
            {
                Cntnmtxt.ForeColor = Color.Red;
            }
            else
            {
                Cntnmtxt.ForeColor = Color.Green;
                Iscntvalidate = "Y";
            }
        }


        private void Clear()
        {
            Idstxt.Text = "";
            Studnmetxt.Text = "";

           
            DateTimePicker1.Text = "";
            Cntnmtxt.Text = "";
            Pintxt.Text = "";
            Citycombo.Text = "";
            Adrestxt.Text = "";


            Idstxt.Focus();
        }


        private void Studnmetxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Studnmetxt.Text) == true)
            {
                errorProvider1.SetError(this.Studnmetxt, "Please Enter Student Name");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void Btnbkh_Click(object sender, EventArgs e)
        {
            Student_Home Sh = new Student_Home();
            Sh.Show();
            this.Close();

        }

        private void Closebtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Idstxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
          
        }

        private void Studnmetxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
           

        }
    }
}
       

      
       

        

       

        

      /*  private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
               
                Idstxt.Text = this.dataGridView1.Rows[0].Cells[0].Value.ToString();
               Studnmetxt.Text = this.dataGridView1.Rows[0].Cells[1].Value.ToString();
                Gender = this.dataGridView1.Rows[0].Cells[2].Value.ToString();
                DateTimePicker1.Text = this.dataGridView1.Rows[0].Cells[3].Value.ToString();
                Cntnmtxt.Text = this.dataGridView1.Rows[0].Cells[4].Value.ToString();
                Pintxt.Text = this.dataGridView1.Rows[0].Cells[5].Value.ToString();
                Citycombo.Text = this.dataGridView1.Rows[0].Cells[6].Value.ToString();
                Adrestxt.Text = this.dataGridView1.Rows[0].Cells[7].Value.ToString();
                Emltxt.Text = this.dataGridView1.Rows[0].Cells[8].Value.ToString();
            }
        }*/

   
