﻿namespace student_management_system
{
    partial class SearchStudents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Btnbkh = new System.Windows.Forms.Button();
            this.Updatesbtn = new System.Windows.Forms.Button();
            this.studentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Pintxt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Deletesbtn = new System.Windows.Forms.Button();
            this.Adrestxt = new System.Windows.Forms.TextBox();
            this.DateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Citycombo = new System.Windows.Forms.ComboBox();
            this.Femrbtn = new System.Windows.Forms.RadioButton();
            this.Gndrbtn = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Idstxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.Cntnmtxt = new System.Windows.Forms.TextBox();
            this.Studnmetxt = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Searchbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btnbkh
            // 
            this.Btnbkh.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btnbkh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btnbkh.ForeColor = System.Drawing.Color.Red;
            this.Btnbkh.Location = new System.Drawing.Point(894, 18);
            this.Btnbkh.Name = "Btnbkh";
            this.Btnbkh.Size = new System.Drawing.Size(143, 41);
            this.Btnbkh.TabIndex = 63;
            this.Btnbkh.Text = "Back";
            this.Btnbkh.UseVisualStyleBackColor = false;
            this.Btnbkh.Click += new System.EventHandler(this.Btnbkh_Click_1);
            // 
            // Updatesbtn
            // 
            this.Updatesbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Updatesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Updatesbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatesbtn.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.Updatesbtn.Location = new System.Drawing.Point(686, 363);
            this.Updatesbtn.Name = "Updatesbtn";
            this.Updatesbtn.Size = new System.Drawing.Size(299, 40);
            this.Updatesbtn.TabIndex = 50;
            this.Updatesbtn.Text = "Edit";
            this.Updatesbtn.UseVisualStyleBackColor = false;
            this.Updatesbtn.Click += new System.EventHandler(this.Updatesbtn_Click);
            // 
            // studentsBindingSource
            // 
            this.studentsBindingSource.DataMember = "Students";
            // 
            // Pintxt
            // 
            this.Pintxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pintxt.Location = new System.Drawing.Point(208, 324);
            this.Pintxt.MaxLength = 6;
            this.Pintxt.Name = "Pintxt";
            this.Pintxt.Size = new System.Drawing.Size(400, 24);
            this.Pintxt.TabIndex = 56;
            this.Pintxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Pintxt_KeyPress);
            this.Pintxt.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Pintxt_KeyUp);
//            this.Pintxt.Leave += new System.EventHandler(this.Pintxt_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(38, 324);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 20);
            this.label10.TabIndex = 45;
            this.label10.Text = "Pin Code";
            // 
            // Deletesbtn
            // 
            this.Deletesbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Deletesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Deletesbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletesbtn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Deletesbtn.Location = new System.Drawing.Point(686, 462);
            this.Deletesbtn.Name = "Deletesbtn";
            this.Deletesbtn.Size = new System.Drawing.Size(299, 40);
            this.Deletesbtn.TabIndex = 52;
            this.Deletesbtn.Text = "Remove";
            this.Deletesbtn.UseVisualStyleBackColor = false;
            this.Deletesbtn.Click += new System.EventHandler(this.Deletesbtn_Click);
            // 
            // Adrestxt
            // 
            this.Adrestxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adrestxt.Location = new System.Drawing.Point(739, 155);
            this.Adrestxt.Multiline = true;
            this.Adrestxt.Name = "Adrestxt";
            this.Adrestxt.Size = new System.Drawing.Size(263, 154);
            this.Adrestxt.TabIndex = 58;
            // 
            // DateTimePicker1
            // 
            this.DateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateTimePicker1.Location = new System.Drawing.Point(208, 403);
            this.DateTimePicker1.Name = "DateTimePicker1";
            this.DateTimePicker1.Size = new System.Drawing.Size(400, 24);
            this.DateTimePicker1.TabIndex = 61;
            // 
            // Citycombo
            // 
            this.Citycombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Citycombo.FormattingEnabled = true;
            this.Citycombo.Items.AddRange(new object[] {
            "Rajkot",
            "Ahmadabad",
            "Baroda",
            "Surat",
            "Junagadh",
            "Jamnager",
            "Anand",
            "Kach",
            "Veraval",
            "Surendranager"});
            this.Citycombo.Location = new System.Drawing.Point(208, 476);
            this.Citycombo.Name = "Citycombo";
            this.Citycombo.Size = new System.Drawing.Size(400, 26);
            this.Citycombo.TabIndex = 62;
//            this.Citycombo.Leave += new System.EventHandler(this.Citycombo_Leave);
            // 
            // Femrbtn
            // 
            this.Femrbtn.AutoSize = true;
            this.Femrbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Femrbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Femrbtn.Location = new System.Drawing.Point(389, 244);
            this.Femrbtn.Name = "Femrbtn";
            this.Femrbtn.Size = new System.Drawing.Size(83, 22);
            this.Femrbtn.TabIndex = 60;
            this.Femrbtn.Text = "Female";
            this.Femrbtn.UseVisualStyleBackColor = true;
            // 
            // Gndrbtn
            // 
            this.Gndrbtn.AutoSize = true;
            this.Gndrbtn.Checked = true;
            this.Gndrbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Gndrbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gndrbtn.Location = new System.Drawing.Point(208, 244);
            this.Gndrbtn.Name = "Gndrbtn";
            this.Gndrbtn.Size = new System.Drawing.Size(64, 22);
            this.Gndrbtn.TabIndex = 59;
            this.Gndrbtn.TabStop = true;
            this.Gndrbtn.Text = "Male";
            this.Gndrbtn.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(16, 403);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 20);
            this.label8.TabIndex = 43;
            this.label8.Text = "Date Of Birth";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(38, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 40;
            this.label3.Text = " Student Id";
            // 
            // Idstxt
            // 
            this.Idstxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Idstxt.Location = new System.Drawing.Point(208, 39);
            this.Idstxt.Name = "Idstxt";
            this.Idstxt.Size = new System.Drawing.Size(400, 24);
            this.Idstxt.TabIndex = 53;
            this.Idstxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Idstxt_KeyPress);
//            this.Idstxt.Leave += new System.EventHandler(this.Idstxt_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(38, 244);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 20);
            this.label7.TabIndex = 42;
            this.label7.Text = "Gender";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(49, 462);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 20);
            this.label12.TabIndex = 46;
            this.label12.Text = "City";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 20);
            this.label4.TabIndex = 41;
            this.label4.Text = "Student Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(24, 178);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 20);
            this.label9.TabIndex = 44;
            this.label9.Text = "Contact Number";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(642, 176);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 20);
            this.label14.TabIndex = 47;
            this.label14.Text = "Address";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Cntnmtxt
            // 
            this.Cntnmtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cntnmtxt.Location = new System.Drawing.Point(208, 174);
            this.Cntnmtxt.MaxLength = 10;
            this.Cntnmtxt.Name = "Cntnmtxt";
            this.Cntnmtxt.Size = new System.Drawing.Size(400, 24);
            this.Cntnmtxt.TabIndex = 55;
            this.Cntnmtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Cntnmtxt_KeyPress);
            this.Cntnmtxt.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Cntnmtxt_KeyUp);
//            this.Cntnmtxt.Leave += new System.EventHandler(this.Cntnmtxt_Leave);
            // 
            // Studnmetxt
            // 
            this.Studnmetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Studnmetxt.Location = new System.Drawing.Point(208, 109);
            this.Studnmetxt.Name = "Studnmetxt";
            this.Studnmetxt.Size = new System.Drawing.Size(400, 24);
            this.Studnmetxt.TabIndex = 54;
            this.Studnmetxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Studnmetxt_KeyPress);
      //      this.Studnmetxt.Leave += new System.EventHandler(this.Studnmetxt_Leave);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Searchbtn);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Deletesbtn);
            this.groupBox1.Controls.Add(this.Updatesbtn);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.Pintxt);
            this.groupBox1.Controls.Add(this.Citycombo);
            this.groupBox1.Controls.Add(this.Adrestxt);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.DateTimePicker1);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.Femrbtn);
            this.groupBox1.Controls.Add(this.Studnmetxt);
            this.groupBox1.Controls.Add(this.Gndrbtn);
            this.groupBox1.Controls.Add(this.Idstxt);
            this.groupBox1.Controls.Add(this.Cntnmtxt);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(3, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1034, 531);
            this.groupBox1.TabIndex = 64;
            this.groupBox1.TabStop = false;
            // 
            // Searchbtn
            // 
            this.Searchbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Searchbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Searchbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchbtn.ForeColor = System.Drawing.Color.Lime;
            this.Searchbtn.Location = new System.Drawing.Point(646, 31);
            this.Searchbtn.Name = "Searchbtn";
            this.Searchbtn.Size = new System.Drawing.Size(225, 40);
            this.Searchbtn.TabIndex = 65;
            this.Searchbtn.Text = "Search";
            this.Searchbtn.UseVisualStyleBackColor = false;
            this.Searchbtn.Click += new System.EventHandler(this.Searchbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(353, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(317, 30);
            this.label1.TabIndex = 65;
            this.label1.Text = "Students Details";
            // 
            // SearchStudents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1049, 622);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Btnbkh);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SearchStudents";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SearchStudents";
            this.Load += new System.EventHandler(this.SearchStudents_Load);
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btnbkh;
        private System.Windows.Forms.Button Updatesbtn;
      //  private student_management_systemDBDataSet1TableAdapters.StudentsTableAdapter studentsTableAdapter;
      //  private student_management_systemDBDataSet1 student_management_systemDBDataSet1;
        private System.Windows.Forms.BindingSource studentsBindingSource;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button Deletesbtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox Idstxt;
        internal System.Windows.Forms.TextBox Studnmetxt;
        internal System.Windows.Forms.RadioButton Femrbtn;
        internal System.Windows.Forms.RadioButton Gndrbtn;
        internal System.Windows.Forms.TextBox Cntnmtxt;
        internal System.Windows.Forms.TextBox Pintxt;
        internal System.Windows.Forms.TextBox Adrestxt;
        internal System.Windows.Forms.DateTimePicker DateTimePicker1;
        internal System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.ComboBox Citycombo;
        private System.Windows.Forms.Button Searchbtn;
    }
}