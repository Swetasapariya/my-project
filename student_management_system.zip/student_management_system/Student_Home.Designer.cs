﻿namespace student_management_system
{
    partial class Student_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Student_Home));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TeacherDetailbtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Printstudrebtn = new System.Windows.Forms.Button();
            this.Managestudbtn = new System.Windows.Forms.Button();
            this.listStudbtn = new System.Windows.Forms.Button();
            this.Edstudbtn = new System.Windows.Forms.Button();
            this.Studdetbtn = new System.Windows.Forms.Button();
            this.Mancoursebtn = new System.Windows.Forms.Button();
            this.Ercbtn = new System.Windows.Forms.Button();
            this.Addcdbtn = new System.Windows.Forms.Button();
            this.FeesDetails = new System.Windows.Forms.Button();
            this.cncbtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TeacherDetailbtn);
            this.groupBox1.Location = new System.Drawing.Point(30, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(276, 127);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // TeacherDetailbtn
            // 
            this.TeacherDetailbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TeacherDetailbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TeacherDetailbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TeacherDetailbtn.Location = new System.Drawing.Point(44, 48);
            this.TeacherDetailbtn.Name = "TeacherDetailbtn";
            this.TeacherDetailbtn.Size = new System.Drawing.Size(185, 54);
            this.TeacherDetailbtn.TabIndex = 0;
            this.TeacherDetailbtn.Text = "Teachers Details";
            this.TeacherDetailbtn.UseVisualStyleBackColor = false;
            this.TeacherDetailbtn.Click += new System.EventHandler(this.TeacherDetailbtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Printstudrebtn);
            this.groupBox2.Controls.Add(this.Managestudbtn);
            this.groupBox2.Controls.Add(this.listStudbtn);
            this.groupBox2.Controls.Add(this.Edstudbtn);
            this.groupBox2.Controls.Add(this.Studdetbtn);
            this.groupBox2.Location = new System.Drawing.Point(353, 60);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(333, 502);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // Printstudrebtn
            // 
            this.Printstudrebtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Printstudrebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Printstudrebtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Printstudrebtn.Location = new System.Drawing.Point(74, 431);
            this.Printstudrebtn.Name = "Printstudrebtn";
            this.Printstudrebtn.Size = new System.Drawing.Size(185, 54);
            this.Printstudrebtn.TabIndex = 5;
            this.Printstudrebtn.Text = "Student Record Print";
            this.Printstudrebtn.UseVisualStyleBackColor = false;
            this.Printstudrebtn.Click += new System.EventHandler(this.Printstudrebtn_Click);
            // 
            // Managestudbtn
            // 
            this.Managestudbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Managestudbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Managestudbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Managestudbtn.Location = new System.Drawing.Point(74, 255);
            this.Managestudbtn.Name = "Managestudbtn";
            this.Managestudbtn.Size = new System.Drawing.Size(185, 54);
            this.Managestudbtn.TabIndex = 4;
            this.Managestudbtn.Text = "Manage Student";
            this.Managestudbtn.UseVisualStyleBackColor = false;
            this.Managestudbtn.Click += new System.EventHandler(this.Managestudbtn_Click);
            // 
            // listStudbtn
            // 
            this.listStudbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.listStudbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.listStudbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.listStudbtn.Location = new System.Drawing.Point(74, 341);
            this.listStudbtn.Name = "listStudbtn";
            this.listStudbtn.Size = new System.Drawing.Size(185, 54);
            this.listStudbtn.TabIndex = 3;
            this.listStudbtn.Text = "Student List";
            this.listStudbtn.UseVisualStyleBackColor = false;
            this.listStudbtn.Click += new System.EventHandler(this.listStudbtn_Click);
            // 
            // Edstudbtn
            // 
            this.Edstudbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Edstudbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Edstudbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Edstudbtn.Location = new System.Drawing.Point(76, 157);
            this.Edstudbtn.Name = "Edstudbtn";
            this.Edstudbtn.Size = new System.Drawing.Size(185, 54);
            this.Edstudbtn.TabIndex = 2;
            this.Edstudbtn.Text = "Edit / Remove";
            this.Edstudbtn.UseVisualStyleBackColor = false;
            this.Edstudbtn.Click += new System.EventHandler(this.Edstudbtn_Click);
            // 
            // Studdetbtn
            // 
            this.Studdetbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Studdetbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Studdetbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Studdetbtn.Location = new System.Drawing.Point(76, 66);
            this.Studdetbtn.Name = "Studdetbtn";
            this.Studdetbtn.Size = new System.Drawing.Size(185, 54);
            this.Studdetbtn.TabIndex = 1;
            this.Studdetbtn.Text = "Student Details";
            this.Studdetbtn.UseVisualStyleBackColor = false;
            this.Studdetbtn.Click += new System.EventHandler(this.Studdetbtn_Click);
            // 
            // Mancoursebtn
            // 
            this.Mancoursebtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Mancoursebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Mancoursebtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Mancoursebtn.Location = new System.Drawing.Point(74, 332);
            this.Mancoursebtn.Name = "Mancoursebtn";
            this.Mancoursebtn.Size = new System.Drawing.Size(185, 54);
            this.Mancoursebtn.TabIndex = 3;
            this.Mancoursebtn.Text = "Manage Course";
            this.Mancoursebtn.UseVisualStyleBackColor = false;
            this.Mancoursebtn.Click += new System.EventHandler(this.Mancoursebtn_Click);
            // 
            // Ercbtn
            // 
            this.Ercbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Ercbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ercbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Ercbtn.Location = new System.Drawing.Point(74, 248);
            this.Ercbtn.Name = "Ercbtn";
            this.Ercbtn.Size = new System.Drawing.Size(185, 54);
            this.Ercbtn.TabIndex = 2;
            this.Ercbtn.Text = "Edit / Remove";
            this.Ercbtn.UseVisualStyleBackColor = false;
            this.Ercbtn.Click += new System.EventHandler(this.Ercbtn_Click);
            // 
            // Addcdbtn
            // 
            this.Addcdbtn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Addcdbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addcdbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Addcdbtn.Location = new System.Drawing.Point(74, 169);
            this.Addcdbtn.Name = "Addcdbtn";
            this.Addcdbtn.Size = new System.Drawing.Size(185, 54);
            this.Addcdbtn.TabIndex = 1;
            this.Addcdbtn.Text = "Course Add";
            this.Addcdbtn.UseVisualStyleBackColor = false;
            this.Addcdbtn.Click += new System.EventHandler(this.Addcdbtn_Click);
            // 
            // FeesDetails
            // 
            this.FeesDetails.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FeesDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FeesDetails.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FeesDetails.Location = new System.Drawing.Point(74, 432);
            this.FeesDetails.Name = "FeesDetails";
            this.FeesDetails.Size = new System.Drawing.Size(185, 54);
            this.FeesDetails.TabIndex = 3;
            this.FeesDetails.Text = "Fees Details";
            this.FeesDetails.UseVisualStyleBackColor = false;
            this.FeesDetails.Click += new System.EventHandler(this.FeesDetails_Click);
            // 
            // cncbtn
            // 
            this.cncbtn.BackColor = System.Drawing.Color.MistyRose;
            this.cncbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cncbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cncbtn.ForeColor = System.Drawing.Color.Tomato;
            this.cncbtn.Location = new System.Drawing.Point(687, 1);
            this.cncbtn.Name = "cncbtn";
            this.cncbtn.Size = new System.Drawing.Size(28, 35);
            this.cncbtn.TabIndex = 4;
            this.cncbtn.Text = "X";
            this.cncbtn.UseVisualStyleBackColor = false;
            this.cncbtn.Click += new System.EventHandler(this.cncbtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(74, 508);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(185, 54);
            this.button1.TabIndex = 5;
            this.button1.Text = "Log Out";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Student_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleVioletRed;
            this.ClientSize = new System.Drawing.Size(717, 607);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Mancoursebtn);
            this.Controls.Add(this.cncbtn);
            this.Controls.Add(this.Ercbtn);
            this.Controls.Add(this.FeesDetails);
            this.Controls.Add(this.Addcdbtn);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Student_Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student_Home";
            this.Load += new System.EventHandler(this.Student_Home_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button TeacherDetailbtn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Printstudrebtn;
        private System.Windows.Forms.Button Managestudbtn;
        private System.Windows.Forms.Button listStudbtn;
        private System.Windows.Forms.Button Edstudbtn;
        private System.Windows.Forms.Button Studdetbtn;
        private System.Windows.Forms.Button Mancoursebtn;
        private System.Windows.Forms.Button Ercbtn;
        private System.Windows.Forms.Button Addcdbtn;
        private System.Windows.Forms.Button FeesDetails;
        private System.Windows.Forms.Button cncbtn;
        private System.Windows.Forms.Button button1;
    }
}