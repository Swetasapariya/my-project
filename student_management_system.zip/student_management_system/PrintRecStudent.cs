﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace student_management_system
{
    public partial class PrintRecStudent : Form
    {
        public PrintRecStudent()
        {
            InitializeComponent();
        }

        String Gender;
       
        private void PrintRecStudent_Load(object sender, EventArgs e)
        {
            Getdata();
            // TODO: This line of code loads data into the 'student_management_systemDBDataSet2.Student' table. You can move, or remove it, as needed.
            //  this.studentTableAdapter.Fill(this.student_management_systemDBDataSet2.Student);
            
           
            
        }

        public void Getdata()
        {

            string sql = "SELECT * from Student";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void Printtxtbtn_Click(object sender, EventArgs e)
        {
            
            String path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\student_data.pdf";
           
            Document doc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);

            try
            {
                // Create a PDF writer to write to the specified path
                PdfWriter writer = PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));

                // Open the document for writing
                doc.Open();

                // Create a new PDF table with the same number of columns as in the DataGridView
                PdfPTable pdfTable = new PdfPTable(dataGridView1.Columns.Count);
                pdfTable.WidthPercentage = 100;

                // Add column headers to the PDF table
                foreach (DataGridViewColumn column in dataGridView1.Columns)
                {
                    PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText))
                    {
                        BackgroundColor = BaseColor.LIGHT_GRAY // Set background color for headers
                    };
                    pdfTable.AddCell(cell);
                }

                // Add rows from the DataGridView to the PDF table
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    // Loop through each cell in the row
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        if (cell.Value != null)
                        {
                            pdfTable.AddCell(new Phrase(cell.Value.ToString()));
                        }
                    }
                }

                // Add the table to the PDF document
                doc.Add(pdfTable);

                // Show a success message
                MessageBox.Show("Data successfully exported to PDF!", "Export to PDF", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Close the document
                if (doc != null)
                {
                    doc.Close();
                }
            }
                      
        }
               private void Btnbkh_Click(object sender, EventArgs e)
        {
            Student_Home aa = new Student_Home();
            aa.Show();
            this.Close();
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {

        }
    }  
}
