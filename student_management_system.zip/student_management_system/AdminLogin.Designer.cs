﻿namespace student_management_system
{
    partial class AdminLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminLogin));
            this.logingif = new System.Windows.Forms.PictureBox();
            this.adloginbtn = new System.Windows.Forms.Button();
            this.clrbtn = new System.Windows.Forms.Button();
            this.cncbtn = new System.Windows.Forms.Button();
            this.userlbl = new System.Windows.Forms.Label();
            this.pswdlbl = new System.Windows.Forms.Label();
            this.usrtxt = new System.Windows.Forms.TextBox();
            this.pswdtxt = new System.Windows.Forms.TextBox();
            this.pwdcek = new System.Windows.Forms.CheckBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.logingif)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // logingif
            // 
            this.logingif.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.logingif.Image = ((System.Drawing.Image)(resources.GetObject("logingif.Image")));
            this.logingif.Location = new System.Drawing.Point(390, 41);
            this.logingif.Name = "logingif";
            this.logingif.Size = new System.Drawing.Size(133, 93);
            this.logingif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logingif.TabIndex = 0;
            this.logingif.TabStop = false;
            // 
            // adloginbtn
            // 
            this.adloginbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adloginbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adloginbtn.ForeColor = System.Drawing.Color.Navy;
            this.adloginbtn.Location = new System.Drawing.Point(285, 314);
            this.adloginbtn.Name = "adloginbtn";
            this.adloginbtn.Size = new System.Drawing.Size(100, 34);
            this.adloginbtn.TabIndex = 1;
            this.adloginbtn.Text = "Log In";
            this.adloginbtn.UseVisualStyleBackColor = true;
            this.adloginbtn.Click += new System.EventHandler(this.adloginbtn_Click);
            // 
            // clrbtn
            // 
            this.clrbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clrbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clrbtn.ForeColor = System.Drawing.Color.LimeGreen;
            this.clrbtn.Location = new System.Drawing.Point(442, 314);
            this.clrbtn.Name = "clrbtn";
            this.clrbtn.Size = new System.Drawing.Size(100, 34);
            this.clrbtn.TabIndex = 2;
            this.clrbtn.Text = "Clear";
            this.clrbtn.UseVisualStyleBackColor = true;
            this.clrbtn.Click += new System.EventHandler(this.clrbtn_Click);
            // 
            // cncbtn
            // 
            this.cncbtn.BackColor = System.Drawing.Color.MistyRose;
            this.cncbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cncbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cncbtn.ForeColor = System.Drawing.Color.Tomato;
            this.cncbtn.Location = new System.Drawing.Point(633, 0);
            this.cncbtn.Name = "cncbtn";
            this.cncbtn.Size = new System.Drawing.Size(28, 35);
            this.cncbtn.TabIndex = 3;
            this.cncbtn.Text = "X";
            this.cncbtn.UseVisualStyleBackColor = false;
            this.cncbtn.Click += new System.EventHandler(this.cncbtn_Click);
            // 
            // userlbl
            // 
            this.userlbl.AutoSize = true;
            this.userlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userlbl.ForeColor = System.Drawing.Color.MediumBlue;
            this.userlbl.Location = new System.Drawing.Point(282, 183);
            this.userlbl.Name = "userlbl";
            this.userlbl.Size = new System.Drawing.Size(93, 18);
            this.userlbl.TabIndex = 4;
            this.userlbl.Text = "User Name";
            // 
            // pswdlbl
            // 
            this.pswdlbl.AutoSize = true;
            this.pswdlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pswdlbl.ForeColor = System.Drawing.Color.MediumBlue;
            this.pswdlbl.Location = new System.Drawing.Point(282, 223);
            this.pswdlbl.Name = "pswdlbl";
            this.pswdlbl.Size = new System.Drawing.Size(83, 18);
            this.pswdlbl.TabIndex = 5;
            this.pswdlbl.Text = "Password";
            // 
            // usrtxt
            // 
            this.usrtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usrtxt.Location = new System.Drawing.Point(390, 183);
            this.usrtxt.Name = "usrtxt";
            this.usrtxt.Size = new System.Drawing.Size(229, 22);
            this.usrtxt.TabIndex = 6;
            this.usrtxt.TextChanged += new System.EventHandler(this.usrtxt_TextChanged);
            this.usrtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.usrtxt_KeyPress);
            this.usrtxt.Leave += new System.EventHandler(this.usrtxt_Leave);
            // 
            // pswdtxt
            // 
            this.pswdtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pswdtxt.Location = new System.Drawing.Point(390, 223);
            this.pswdtxt.Name = "pswdtxt";
            this.pswdtxt.Size = new System.Drawing.Size(229, 22);
            this.pswdtxt.TabIndex = 7;
            this.pswdtxt.UseSystemPasswordChar = true;
            this.pswdtxt.TextChanged += new System.EventHandler(this.pswdtxt_TextChanged);
            this.pswdtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.pswdtxt_KeyPress);
            this.pswdtxt.Leave += new System.EventHandler(this.pswdtxt_Leave);
            // 
            // pwdcek
            // 
            this.pwdcek.AutoSize = true;
            this.pwdcek.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pwdcek.ForeColor = System.Drawing.Color.Tomato;
            this.pwdcek.Location = new System.Drawing.Point(385, 251);
            this.pwdcek.Name = "pwdcek";
            this.pwdcek.Size = new System.Drawing.Size(155, 21);
            this.pwdcek.TabIndex = 8;
            this.pwdcek.Text = "Check Your Password";
            this.pwdcek.UseCompatibleTextRendering = true;
            this.pwdcek.UseVisualStyleBackColor = false;
            this.pwdcek.CheckedChanged += new System.EventHandler(this.pwdcek_CheckedChanged);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // AdminLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(661, 395);
            this.Controls.Add(this.pwdcek);
            this.Controls.Add(this.pswdtxt);
            this.Controls.Add(this.usrtxt);
            this.Controls.Add(this.pswdlbl);
            this.Controls.Add(this.userlbl);
            this.Controls.Add(this.cncbtn);
            this.Controls.Add(this.clrbtn);
            this.Controls.Add(this.adloginbtn);
            this.Controls.Add(this.logingif);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminLogin";
            this.Load += new System.EventHandler(this.AdminLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logingif)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox logingif;
        private System.Windows.Forms.Button adloginbtn;
        private System.Windows.Forms.Button clrbtn;
        private System.Windows.Forms.Button cncbtn;
        private System.Windows.Forms.Label userlbl;
        private System.Windows.Forms.Label pswdlbl;
        private System.Windows.Forms.TextBox usrtxt;
        private System.Windows.Forms.TextBox pswdtxt;
        private System.Windows.Forms.CheckBox pwdcek;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}