﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management_system
{
    public partial class EditDeleteCourse : Form
    {
        public EditDeleteCourse()
        {
            InitializeComponent();
            this.comboBoxCourse.SelectedIndexChanged += new System.EventHandler(this.comboBoxCourse_SelectedIndexChanged);
            //Fillcombo();
        }

     
        private void Coursename_SelectedIndexChanged(object sender, EventArgs e)
        {

           Coursenameprtxt.Text = comboBoxCourse.SelectedItem.ToString();
        }

        private void Deleteidbtn_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM Courses where CourseId = '" + Courseidtxt.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show("Course Record Deleted!", "Delete Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
            GetData();
        }

        private void Updatedetailsbtn_Click(object sender, EventArgs e)
        {
          
           
            string sql = "UPDATE Courses SET  CousreName = '" + Coursenameprtxt.Text + "', Timeduration = '" + Numbertxt.Text + "', Fees = '" +Coursefeetxt.Text + "'   WHERE CourseId = '" + Courseidtxt.Text+"'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GetData();
            MessageBox.Show("Course Record Updated!", "Update Student", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }
        private void GetData()
        {
            string sql = "SELECT * FROM Courses";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
          
            dataGridView1.DataSource = dt;
        }



        private void EditDeleteCourse_Load(object sender, EventArgs e)
        {
            
            this.comboBoxCourse.SelectedIndexChanged += new System.EventHandler(this.comboBoxCourse_SelectedIndexChanged);
            GetData();
        }

       

        private void comboBoxCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxCourse.SelectedItem != null)
            {
                string selectedCourse = comboBoxCourse.SelectedItem.ToString();
                Coursenameprtxt.Text = selectedCourse;

                GetData();
            }
        }

        private void Btnbkh_Click(object sender, EventArgs e)
        {
            Student_Home student= new Student_Home();
            student.Show();
            this.Close();
        }

     

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0 && dataGridView1.Rows.Count > 0)
             {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                if (row != null)
                {
                    Courseidtxt.Text = row.Cells[0].Value.ToString();
                    Coursenameprtxt.Text = row.Cells[1].Value.ToString();
                    Numbertxt.Text = row.Cells[2].Value.ToString();
                    Coursefeetxt.Text = row.Cells[3].Value.ToString();
                }
            }

        }

        private void Courseidtxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Courseidtxt.Text) == true)
            {
                errorProvider1.SetError(this.Courseidtxt, "Please Enter Student Name");
            }
            else
            {
                errorProvider1.Clear();
            }

        }

        private void Coursenameprtxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Coursenameprtxt.Text) == true)
            {
                errorProvider1.SetError(this.Coursenameprtxt, "Please Enter Student Name");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void Coursefeetxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Coursefeetxt.Text) == true)
            {
                errorProvider1.SetError(this.Coursefeetxt, "Please Enter Student Name");
            }
            else
            {
                errorProvider1.Clear();
            }

        }

        private void Updatedetailsbtn_Click_1(object sender, EventArgs e)
        {

        }

        private void Btnbkh_Click_1(object sender, EventArgs e)
        {
            Student_Home ha = new Student_Home();
            ha.Show();
            this.Close();

        }
    }
}

