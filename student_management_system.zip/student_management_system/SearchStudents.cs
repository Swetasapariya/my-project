﻿ using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
//using System.Data.SqlClient;
using System.Data.Sql;
using System.Xml.Linq;


namespace student_management_system
{
    public partial class SearchStudents : Form
    {
        public SearchStudents()
        {
            InitializeComponent();
        }
        String Gender;



        private void Updatesbtn_Click(object sender, EventArgs e)
        {
            if (Gndrbtn.Checked)
            {
                Gender = "Male";

            }
            else if (Femrbtn.Checked)
            {
                Gender = "Female";
            }
            else
            {
                Gender = "Not select Gender";
            }
            // string gender = Gndrbtn.Checked ? "Male" : Femrbtn.Checked ? "Female" : "Other";
            if (string.IsNullOrWhiteSpace(Studnmetxt.Text))
            {
                MessageBox.Show("Please enter the student name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string sql = "UPDATE Student SET Student_Name = '" + Studnmetxt.Text + "', Gender = '" + Gender + "', Date_of_Birth = '" + DateTimePicker1.Text + "', Contact_Number = '" + Cntnmtxt.Text + "', Pin_Code = '" + Pintxt.Text + "', City = '" + Citycombo.Text + "', Address = '" + Adrestxt.Text + "'  where Student_Id='" + Idstxt.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            MessageBox.Show("Student Record Updated!", "Update Student", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }


        private void Clear()
        {
            Idstxt.Text = "";
            Studnmetxt.Text = "";
            Gndrbtn.Checked = false;
            Femrbtn.Checked = false;
            DateTimePicker1.Value = DateTime.Now;
            Cntnmtxt.Text = "";
            Pintxt.Text = "";
            Citycombo.SelectedIndex = -1; 
            Adrestxt.Text = "";
            Idstxt.Focus();
        }
        private void Deletesbtn_Click(object sender, EventArgs e)
        {

            string sql = "DELETE FROM Student where Student_Id = '" + Idstxt.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show("Student Record Deleted!", "Delete Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Searchidtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Btnbkh_Click(object sender, EventArgs e)
        {
            PrintRecStudent prs = new PrintRecStudent();
            prs.Show();
            this.Close();

        }

        private void Searchbtn_Click(object sender, EventArgs e)
        {
            string sql = "SELECT Student_Id, Student_Name, Gender, Date_of_Birth, Contact_Number, Pin_Code, City, Address FROM Student WHERE Student_Id = '" + Idstxt.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql,studentclass.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                Idstxt.Text = row["Student_Id"].ToString();
                Studnmetxt.Text = row["Student_Name"].ToString();
                DateTimePicker1.Value = Convert.ToDateTime(row["Date_of_Birth"]);
                Cntnmtxt.Text = row["Contact_Number"].ToString();
                Pintxt.Text = row["Pin_Code"].ToString();
                Citycombo.Text = row["City"].ToString();
                Adrestxt.Text = row["Address"].ToString();

                // Reset gender radio buttons
                Gndrbtn.Checked = false;
                Femrbtn.Checked = false;

                // Set the gender based on the retrieved data
                string gender = row["Gender"].ToString();
                if (gender.Equals("Male", StringComparison.OrdinalIgnoreCase))
                {
                    Gndrbtn.Checked = true;
                }
                else if (gender.Equals("Female", StringComparison.OrdinalIgnoreCase))
                {
                    Femrbtn.Checked = true;
                }
            }
            else
            {
                MessageBox.Show("No records found for the provided Student ID.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
            }
        }

        private void SearchStudents_Load(object sender, EventArgs e)
        {

        }

        private void Btnbkh_Click_1(object sender, EventArgs e)
        {
            Student_Home me = new Student_Home();
            me.Show();
                this.Close();
        }

        

       

      

       

       

        private void Idstxt_KeyPress(object sender, KeyPressEventArgs e)
        {
           
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
           
        }

        private void Studnmetxt_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
          
        }

        private void Cntnmtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
           
        }

        private void Pintxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
          

        }

        private void Pintxt_KeyUp(object sender, KeyEventArgs e)
        {
            String Ispinvalidate = "N";
            if (Pintxt.Text.Length < 6)
            {
                Pintxt.ForeColor = Color.Red;

            }
            else
            {
                Pintxt.ForeColor = Color.Green;

                Ispinvalidate = "Y";
            }
        }

        private void Cntnmtxt_KeyUp(object sender, KeyEventArgs e)
        {
            String Iscntvalidate = "N";
            if (Cntnmtxt.Text.Length < 10)
            {
                Cntnmtxt.ForeColor = Color.Red;
            }
            else
            {
                Cntnmtxt.ForeColor = Color.Green;
                Iscntvalidate = "Y";
            }

        }
    }
}
